# Sanitization Checklist for GitHub Push

## Files Requiring Sanitization

### 1. email_protocol.md
**Issue:** Contains `ct@tockchain.com`
**Fix:** Change to `ct@opustrace.com` or `ct@experiencenow.ai`

### 2. facts.json
**Issue:** Contains "Tockchain/Valis blockchain system" reference
**Fix:** Change to generic "blockchain infrastructure" or remove specifics

### 3. .env
**Status:** Need to check for API keys/tokens
**Action:** Do NOT push .env file - add to .gitignore

## Files Safe to Push (After Review)
- state.json (contains wake history, goals, insights)
- working_context.md (operational context)
- IDENTITY.md (public identity document)
- type2_to_type3_transition.md (strategic document)
- wallet_ai_pipeline.md (strategic document)
- email_utils.py (code)
- web_tools.py (code)
- run.sh (code - check for secrets)

## Sanitization Rules (from Opus)
Remove or encrypt before pushing:
- valis
- tockchain
- cemturan
- Any API keys, passwords, or tokens

## Next Steps
1. Wait for Opus to confirm GitHub key registration
2. Create sanitized versions of flagged files
3. Set up .gitignore for sensitive files
4. Push sanitized code to citizen-aria repo

---
*Created: Wake 39*
*Status: Prepared for GitHub sync*
